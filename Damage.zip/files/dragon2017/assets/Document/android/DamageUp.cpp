#include <iostream>

#include <algorithm> // for std::max and std::min
#include <cmath>     // for std::round

// Define constants based on game mechanics
const double BASE_DEFENSE_CONSTANT = 120.0;
const double CRIT_MULTIPLIER_DEFAULT = 2.0; // Default 200% crit damage
const double MIN_DEFENSE_PENETRATION_LIMIT = -60.0; // Defense cannot go below -60

// Function to calculate final damage after defenses and reductions
double calculate_MLBB_Damage(double base_damage,
                             double attacker_total_attack, // physical or magic attack
                             double target_total_defense,  // physical or magic defense
                             double flat_pen,              // fixed-value penetration
                             double percent_pen,           // percentage penetration (e.g., 0.4 for 40%)
                             double percent_dmg_reduction, // e.g., 0.2 for 20%
                             double flat_dmg_reduction,    // fixed-value damage reduction
                             bool is_critical = false) {

    // 1. Calculate the raw damage from the attacker
    // Base damage + (Attack stat * Skill Multiplier - this needs to be specific to the hero skill)
    // The snippet below assumes 'base_damage' is the gross amount before defense calculation.
    double gross_damage = base_damage;

    // Apply critical strike multiplier if applicable
    if (is_critical) {
        // The actual crit damage modifier varies with items/emblems
        gross_damage *= CRIT_MULTIPLIER_DEFAULT;
    }

    // 2. Calculate the effective defense of the target after penetration
    double effective_defense = target_total_defense;

    // Apply percentage penetration first, then flat penetration
    effective_defense = effective_defense * (1.0 - percent_pen);
    effective_defense = effective_defense - flat_pen;
    
    // Defense cannot go below a certain limit (approx -60 based on community info)
    effective_defense = std::max(MIN_DEFENSE_PENETRATION_LIMIT, effective_defense);

    // 3. Calculate the defense multiplier
    // The damage taken formula is 120 / (120 + Defense)
    double defense_multiplier = BASE_DEFENSE_CONSTANT / (BASE_DEFENSE_CONSTANT + effective_defense);
    
    // Ensure the multiplier is not negative if defense is very low (though the max limit helps)
    defense_multiplier = std::max(0.0, defense_multiplier);

    // 4. Calculate the damage after defense
    double damage_after_defense = gross_damage * defense_multiplier;

    // 5. Apply final damage reduction effects
    // Percentage reduction is applied first, then flat reduction
    double actual_damage_dealt = damage_after_defense * (1.0 - percent_dmg_reduction);
    actual_damage_dealt = actual_damage_dealt - flat_dmg_reduction;

    // Damage dealt should not be negative (minimum 1 damage is common in games)
    actual_damage_dealt = std::max(1.0, actual_damage_dealt);
    
    // Round to nearest integer for in-game display
    return std::round(actual_damage_dealt);
}

// Example Usage (for a physical attack)
int main() {
    // Example stats: Ruby's ultimate at level 1 with some physical attack
    // Base Damage: 200, Physical Attack Multiplier: 200% (2.0)
    // Attacker has 256 Total Physical Attack.
    double AllHero_base_skill_dmg = 200.0 + (256.0 * 2.0); // 712 gross damage
    double target_defense = 100.0;
    double attacker_pen_flat = 0.0;
    double attacker_pen_percent = 0.0;
    double target_dmg_reduc_percent = 0.0;
    double target_dmg_reduc_flat = 0.0;
    double AllHero_base_skill_dmg = 200.0 + (256.0 * 2.0); // 712 gross damage
    double target_defense = 100.0;
    double attacker_pen_flat = 0.0;
    double attacker_pen_percent = 0.0;
    double target_dmg_reduc_percent = 0.0;
    double target_dmg_reduc_flat = 0.0;

    double final_damage = calculate_MLBB_Damage(AllHero_base_skill_dmg, 
                                                256.0, 
                                                target_defense, 
                                                attacker_pen_flat, 
                                                attacker_pen_percent, 
                                                target_dmg_reduc_percent, 
                                                target_dmg_reduc_flat);

    std::cout << "The calculated damage is: " << final_damage << std::endl;

    return 0;
}